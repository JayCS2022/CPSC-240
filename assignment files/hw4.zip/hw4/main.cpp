//****************************************************************************************************************************
//Program name: "Computer Benchmark".  This program will measure the performance of your hardware.                           *
//Copyright (C) 2023 Allen Dai                                                                                               *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************




//=======1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**
//Author information
//  Author name: Allen Dai
//  Author email: allendai@csu.fullerton.edu
//
//Program information
//  Program name: Computer Benchmark
//  Programming languages: Main function in C++; executive function in X86-64
//  Date program began: 2023-Apr-15
//  Date of last update: 2023-Apr-16
//  Comments reorganized: 2023-Apr-16
//  Files in the program: main.cpp getradicand.asm get_clock_freq.asm manager.asm r.sh
//
//Purpose
//  This program will measure the performance of your hardware.
//
//This file
//  File name: main.cpp
//  Language: C++
//  Max page width: 132 columns
//  Optimal print specification: 7 point font, monospace, 132 columns, 8½x11 paper
//  Compile: g++ -c -Wall -no-pie -m64 -std=c++20 -o main.o main.cpp
//  Link: g++ -m64 -no-pie -o a.out manager.o main.o get_clock_freq.o getradicand.o -std=c++20
//
//Execution: ./a.out
//
//===== Begin code area ===================================================================================================================================================
#include <iostream>

extern "C" double assignment4();

using namespace std;

int main(int argc, char* argv[])
{
    printf("\n");
    double ret = assignment4();
    printf("The main function has received this number %1.5lf and will keep it for future reference.\n", ret);
    printf("The main function will return a zero to the operating system.\n");
    printf("\n");
}