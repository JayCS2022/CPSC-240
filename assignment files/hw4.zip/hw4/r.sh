#!/bin/bash

#Author: Allen Dai
#Program name: Computer Benchmark


rm *.o
rm *.lis
rm *.out

echo "compile main.cpp using the g++ compiler standard 2020"
g++ -c -Wall -no-pie -m64 -std=c++20 -o main.o main.cpp

echo "Assemble manager.asm"
nasm -f elf64 -l manager.lis -o manager.o manager.asm

echo "Assemble get_clock_freq.asm"
nasm -f elf64 -l get_clock_freq.lis -o get_clock_freq.o get_clock_freq.asm

echo "Assemble getradicand.asm"
nasm -f elf64 -l getradicand.lis -o getradicand.o getradicand.asm

echo "Link object files using the g++ Linker standard 2020"
g++ -m64 -no-pie -o a.out manager.o main.o get_clock_freq.o getradicand.o -std=c++20

echo "Run the Pythagoras Program: "
./a.out

echo "Script file has terminated."

rm *.o
rm *.lis
rm *.out